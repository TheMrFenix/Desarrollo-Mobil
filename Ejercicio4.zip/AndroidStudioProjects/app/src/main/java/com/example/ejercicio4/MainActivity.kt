package com.example.ejercicio4

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.lang.StringBuilder

class MainActivity : AppCompatActivity() {
    private lateinit var et1: EditText
    private lateinit var et2: EditText
    private lateinit var tv1: TextView
    private lateinit var tv2: TextView
    private lateinit var tv3: TextView

    var productList = mutableMapOf<String,Float>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        et1=findViewById(R.id.nombre_text)
        et2=findViewById(R.id.precio_text)
        tv1=findViewById(R.id.view1_text)
        tv2=findViewById(R.id.menor1_text)
        tv3=findViewById(R.id.mayor1_text)
    }

    fun registrarProducto(view: View){
        val productName = et1.text.toString()
        val productPrice = et2.text.toString().toFloatOrNull()

        if (productPrice != null){
            productList[productName] = productPrice

            et1.text.clear()
            et2.text.clear()

            Toast.makeText(this, "Producto Registrado", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Ingrese un precio valido", Toast.LENGTH_LONG).show()
        }
    }
    fun mostrarProductos(view: View){
        val sb = StringBuilder()

        for ((name, price) in productList){
            sb.append("$name - $price\n")
        }
        tv1.text = sb.toString()
    }
    fun menorPrecio(view: View){
        if (productList.isEmpty()){
            Toast.makeText(this, "No hay productos registrados", Toast.LENGTH_LONG).show()
            return
        }

        val minValue = productList.minByOrNull { it.value }

        if (minValue != null){
            tv2.text = "${minValue.key} - ${minValue.value}"
        } else {
            Toast.makeText(this, "No se encontro el producto", Toast.LENGTH_LONG).show()
        }
    }
    fun mayorPrecio(view: View){
        if (productList.isEmpty()){
            Toast.makeText(this, "No hay productos registrados", Toast.LENGTH_LONG).show()
            return
        }

        val maxValue = productList.maxByOrNull { it.value }

        if (maxValue != null) {
            tv3.text = "${maxValue.key} - ${maxValue.value}"
        } else {
            Toast.makeText(this, "No se encontro el producto", Toast.LENGTH_LONG).show()
        }
    }
}
